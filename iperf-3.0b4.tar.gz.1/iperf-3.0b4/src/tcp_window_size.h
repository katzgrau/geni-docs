int set_tcp_windowsize(int sock, int bufsize, int dir);
int get_tcp_windowsize(int sock, int dir);
