#ifndef __IPERF_UTIL_H
#define __IPERF_UTIL_H

void get_uuid(char *);

int is_closed(int);

#endif
